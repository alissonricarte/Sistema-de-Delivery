package main.java.Enums;

public enum StatusPedido {
    PENDENTE, CONFIRMADO, PREPARANDO, SAIU_PARA_ENTREGA, ENTREGUE, CANCELADO

}
