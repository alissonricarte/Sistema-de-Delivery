package main.java.models.interfaces;

public interface ITaxavel {

    double calcularTaxa();
}
