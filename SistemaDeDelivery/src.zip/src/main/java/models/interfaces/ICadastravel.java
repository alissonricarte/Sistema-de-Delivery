package main.java.models.interfaces;

public interface ICadastravel {

    void cadastrar();
    void listar();
    void buscar();
}
